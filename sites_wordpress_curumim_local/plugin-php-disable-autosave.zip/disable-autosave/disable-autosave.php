<?php
/**
 * Plugin Name: Disable Autosave
 * Description: Desativa o autosave do editor do WordPress.
 * Version: 1.0
 * Author: Seu Nome
 */

function disable_autosave() {
    if (is_admin()) {
        wp_deregister_script('autosave');
    }
}
add_action('admin_enqueue_scripts', 'disable_autosave');
